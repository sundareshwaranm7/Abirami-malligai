document.addEventListener("DOMContentLoaded", function() {
    alert("Welcome to Abirami Malligai!");
});